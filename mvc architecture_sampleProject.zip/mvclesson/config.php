<?php

class config  
{	
	function __construct() {
		$this->host = "localhost";
		$this->user  = "root";
		$this->pass = "";
		$this->db = "mydb";
	}
}

?>